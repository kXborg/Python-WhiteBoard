### Contour Analysis instructional notebook.


Note that it uses OpenCV-Python. If you don't have it yet, do the following.

```
pip install -r requirement.txt
```